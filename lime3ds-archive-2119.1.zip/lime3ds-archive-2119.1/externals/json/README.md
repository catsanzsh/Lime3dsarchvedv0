JSON for Modern C++
===================

v3.11.3

This is a mirror providing the single required header file.

The original repository can be found at:
https://github.com/nlohmann/json/commit/9cca280a4d0ccf0c08f47a99aa71d1b0e52f8d03
