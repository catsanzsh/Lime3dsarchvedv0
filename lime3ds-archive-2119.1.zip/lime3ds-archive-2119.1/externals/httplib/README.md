From https://github.com/yhirose/cpp-httplib/commit/cbca63f091ef1147ff57e90eb1ee5e558aa05d2c 

MIT License

===

cpp-httplib

A C++11 header-only HTTP library.

It's extremely easy to setup. Just include httplib.h file in your code!

Inspired by Sinatra and express.

© 2017 Yuji Hirose

